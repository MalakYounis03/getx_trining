import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/state_manager.dart';
import 'package:getx_trining/user_controller.dart';
import 'package:getx_trining/user_model.dart';

class CommentsScreen extends GetView<UserController> {
  const CommentsScreen({super.key, required this.userModel});
  final UserModel userModel;
  @override
  Widget build(BuildContext context) {
    controller.getComments(userModel.id);
    return Scaffold(
      appBar: AppBar(title: Text("comments page")),
      body: Column(
        children: [
          Card(
            color: const Color.fromARGB(255, 233, 119, 157),
            margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            child: ListTile(
              title: Text(
                userModel.title,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(userModel.body),
            ),
          ),
          Divider(color: Colors.pink),

          Expanded(
            child: Obx(
              () => controller.isCommentsLoading.value
                  ? Center(child: CircularProgressIndicator())
                  : ListView.builder(
                      itemBuilder: (context, index) {
                        final comment = controller.commentsList[index];
                        return Card(
                          color: const Color.fromARGB(255, 233, 119, 157),

                          margin: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 6,
                          ),
                          child: ListTile(
                            title: Text(
                              comment.name,
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            subtitle: Text(comment.email),
                          ),
                        );
                      },
                      itemCount: controller.commentsList.length,
                    ),
            ),
          ),
        ],
      ),
    );
  }
}
